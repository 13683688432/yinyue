package com.example.yinyue;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MusicAdapter extends RecyclerView.Adapter<MusicAdapter.LocalMusicViewHolder>{
    Context context;
    List<Music> mData;

    OnItemClickListener onItemClickListener;

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public interface OnItemClickListener{
        public void OnItemClick(View view, int position);
    }
    public MusicAdapter(Context context, List<Music> mData) {
        this.context = context;
        this.mData = mData;
    }

    @NonNull
    @Override
    public LocalMusicViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_music,parent,false);
        LocalMusicViewHolder holder = new LocalMusicViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull LocalMusicViewHolder holder, final int position) {
        Music music = mData.get(position);
        holder.num.setText(music.getNum());
        holder.name.setText(music.getName());
        holder.singer.setText(music.getSinger());
        holder.time.setText(music.getTime());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickListener.OnItemClick(v,position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    class LocalMusicViewHolder extends RecyclerView.ViewHolder{
        TextView num,name,singer,time;
        public LocalMusicViewHolder(View itemView) {
            super(itemView);
            num = itemView.findViewById(R.id.music_num);
            name = itemView.findViewById(R.id.music_name);
            singer = itemView.findViewById(R.id.music_singer);
            time = itemView.findViewById(R.id.music_time);
        }
    }
}
