package com.example.yinyue;

public interface onDestory {
}
