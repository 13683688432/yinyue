package com.example.yinyue;

import android.renderscript.ScriptGroup;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Music {
    private String singer; //歌手名
    private String name;//歌曲名
    private String time;//歌曲时长
    private String num;     //歌曲编号
    private String path;  //歌曲文件存放路径


    public Music(String num,String name,String singer,String path,String time) {
        this.num = num;
        this.singer = singer;
        this.name = name;
        this.path = path;
        this.time = time;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getSinger() {
        return singer;
    }

    public void setSinger(String singer) {
        this.singer = singer;
    }
    public void setTime(String name) {
        this.time = time;
    }

    public String getTime() {
        return time;
    }
}
