package com.example.yinyue;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements onDestory {
    String geci[];    //用于存放歌词
    String gecitime[];     //用于存放歌词时间
    private ObjectAnimator donghua;
    List<Music>mData;      //歌曲的数据源
    private MusicAdapter Adapter;
   ImageButton shang,xia,play,tianjia,shanchu,qiege;
   TextView music_name,music_singer,music_num,music_time;
   RecyclerView RC;
   int dangqian;  //当前播放歌曲的位置  -1为没有
    int qiehuan=0;       //默认为0   0是顺序播放  1是随机播放
    int pause = 0;
    MediaPlayer mediaPlayer;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //创建旋转动画
        dangqian = -1;
        ImageView xuanzhuan = findViewById(R.id.xuanzhuan);
        donghua = ObjectAnimator.ofFloat(xuanzhuan, "rotation", 0f, 360f);//添加旋转动画，旋转中心默认为控件中点
        donghua.setDuration(15000);//设置动画时间
        donghua.setInterpolator(new LinearInterpolator());//动画时间线性渐变
        donghua.setRepeatCount(ObjectAnimator.INFINITE);
        donghua.setRepeatMode(ObjectAnimator.RESTART);

        init();
        mediaPlayer = new MediaPlayer();
        mData = new ArrayList<>();



        Adapter = new MusicAdapter(this,mData);         //给recyclerview设置适配器
        RC.setAdapter(Adapter);
        LinearLayoutManager LL = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        RC.setLayoutManager(LL);        //这边设置一下垂直滑动
        jiazaimusic();     //加载音乐文件
        setEventListener();
        TimerTask timerTask = new TimerTask() {      //设置一个时间任务  每500ms更新一次
            @Override
            public void run() {
                if(mediaPlayer.isPlaying()){
                    updateTime();
                    if(!geci[0].equals("0")) {    //当歌词不是空的时候再去刷新
                        updategeci(geci, gecitime);
                    }
                }
            }
        };
        new Timer().scheduleAtFixedRate(timerTask,0,500);//这里设置500ms更新一次



        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {     //这里是播放以及暂停  并且图片进行切换
                if (dangqian==-1) {     //如果当前没有选中的歌曲
                    Toast.makeText(MainActivity.this,"没有指定歌曲",Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    if (!mediaPlayer.isPlaying()) {
                        mediaPlayer.start();
                        donghua.start();
                        play.setImageDrawable(getResources().getDrawable(R.mipmap.zanting));
                    } else if (mediaPlayer.isPlaying()) {
                        mediaPlayer.pause();
                        donghua.pause();
                        play.setImageDrawable(getResources().getDrawable(R.mipmap.bofang));
                    }
                }
            }
        });
        xia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里是切换下一首歌
                //下面是顺序播放的切歌
                if(dangqian==-1){      //这里判断了是否用户直接点击了切歌
                    Toast.makeText(MainActivity.this,"没有指定歌曲,无法进行切歌",Toast.LENGTH_SHORT).show();
                }
                else {
                    if (dangqian == mData.size() - 1 && qiehuan == 0) {      //判断是否为最后一首歌以及是否是顺序播放
                        dangqian = 0;
                        Music music = mData.get(dangqian);
                        playMusicInMusicBean(music);
                        donghua.resume();
                        donghua.start();
                    }
                    else if (dangqian != -1 && dangqian != mData.size() && qiehuan == 0) {   //不是最后一首歌的话需要判断是否用户直接点击了切换下一首歌
                        dangqian = dangqian + 1;
                        Music music = mData.get(dangqian);
                        playMusicInMusicBean(music);
                        donghua.resume();
                        donghua.start();
                    }
                    //接下来是随机播放
                    else if(qiehuan==1){       //判断随机播放
                        dangqian = ((int)(Math.random()*100)+1)%(mData.size());     //这里利用随机数除以mData的大小  最后得数最大正好比mData.size()小1  可以覆盖所有歌曲
                        Music music = mData.get(dangqian);
                        playMusicInMusicBean(music);
                        donghua.resume();
                        donghua.start();
                    }

                }
            }
        });
        shang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里是切换上一首歌
                //下面是顺序播放的切歌
                if(dangqian==-1){      //这里判断了是否用户直接点击了切歌
                    Toast.makeText(MainActivity.this,"没有指定歌曲,无法进行切歌",Toast.LENGTH_SHORT).show();
                }else {
                    if (dangqian == 0 && qiehuan == 0) {      //判断是否为第一首歌以及是否是顺序播放
                        dangqian = mData.size() - 1;
                        Music music = mData.get(dangqian);
                        playMusicInMusicBean(music);
                        donghua.resume();
                        donghua.start();
                    }
                    else if (dangqian != -1 && dangqian != 0 && qiehuan == 0) {   //不是第一首歌的话需要判断是否用户直接点击了切换上一首歌
                        dangqian = dangqian - 1;
                        Music music = mData.get(dangqian);
                        playMusicInMusicBean(music);
                        donghua.resume();
                        donghua.start();
                    }
                    //接下来是随机播放   随机播放是需要记录上一首歌的
                    else if(qiehuan==1){       //判断随机播放
                        dangqian = ((int)(Math.random()*100)+1)%(mData.size());     //这里利用随机数除以mData的大小  最后得数最大正好比mData.size()小1  可以覆盖所有歌曲
                        Music music = mData.get(dangqian);
                        playMusicInMusicBean(music);
                        donghua.resume();
                        donghua.start();
                    }
                }
            }
        });
        tianjia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里是添加歌曲   只需要调用 jiazaiyinyue（）方法即可
                mData.clear();
                jiazaimusic();
                Adapter.notifyDataSetChanged();   //记得更新适配器


            }
        });
        shanchu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里是删除歌曲
                ImageButton play = findViewById(R.id.play);
                play.setImageDrawable(getResources().getDrawable(R.mipmap.bofang));   //删除歌曲后将play按钮设为暂停的图标
                mediaPlayer.stop();
                donghua.pause();
                mData.remove(mData.get(dangqian));
                TextView tx2 = findViewById(R.id.tx2);
                tx2.setText("00:00");
                TextView tx1 = findViewById(R.id.tx1);
                tx1.setText("00:00");
                Adapter.notifyDataSetChanged();       //这里先停止播放 然在数组中删除该歌曲 然后提醒view适配器更新列表
                SeekBar jindutiao = findViewById(R.id.jindutiao);
                jindutiao.setProgress(0);   //进度条需要清零
//                dangqian = -1;   //删除歌曲以后  当前播放歌曲要设置为没有
            }
        });
        qiege.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(qiehuan==0) {
                    qiehuan = 1;
                    qiege.setImageDrawable(getResources().getDrawable(R.mipmap.suiji));
                }
                else if(qiehuan==1) {
                    qiehuan = 0;
                    qiege.setImageDrawable(getResources().getDrawable(R.mipmap.shunxu));
                }
            }
        });



    }

    private void setEventListener() {
        /* 设置每一项的点击事件*/
        Adapter.setOnItemClickListener(new MusicAdapter.OnItemClickListener() {
            public void OnItemClick(View view, int position) {
                dangqian = position;
                Music music = mData.get(position);
                playMusicInMusicBean(music);
                donghua.resume();
                donghua.start();
            }
        });
    }
    private void updateTime(){    //更新进度条
        runOnUiThread(() ->{
            int jindu = mediaPlayer.getCurrentPosition();  //获取当前歌曲播放进度
            int s = jindu/1000;
            int m = s/60;
            s = s-m*60;
            String time = String.format("%02d:%02d",m,s);
            SeekBar jindutiao = findViewById(R.id.jindutiao);
            //这里出现了时间的最小单位问题   我需要将当前歌曲时间总长计算出来
            int i = mediaPlayer.getDuration();
            jindutiao.setProgress(jindu*jindutiao.getMax()/i);   //给进度条设置进度
                        //进度条当前进度*进度条最大值 / 歌曲总时长  得到一个一百以内的数
            TextView tx1 = findViewById(R.id.tx1);
            tx1.setText(time);      //给第一个时间设置时间
            TextView tx2 = findViewById(R.id.tx2);
            if(tx1.getText().toString().equals(tx2.getText().toString())&&mediaPlayer.isPlaying()){
                //这里本想当歌曲进度为百分之百的时候自动点击切换下一首按钮
                //但实际上总是有些歌曲没有办法让其乘积到达一百
                //因此我换了用两个显示时间的textview如果相同来判断是否音乐播放完毕
                //但要注意到  在初始的时候未选择音乐时  两个TEXTVIEW都是显示的“00:00”相同
                //  要排除这种情况
                xia.performClick();
            }
        });


    }
    public void updategeci(String []geci,String []gecitime){   //这里需要两个参数  歌词时间和歌词
        runOnUiThread(() -> {
            TextView gecixianshi = findViewById(R.id.geci);
            TextView tx1 = findViewById(R.id.tx1);
            if (geci[0].equals("0")) {
                gecixianshi.setText("当前歌曲没有找到歌词文件");
            } else {
                for (int i = 0; i < geci.length; i++) {
                    if (gecitime[i].equals(tx1.getText().toString())) {
                        gecixianshi.setText(geci[i]);  //如果时间相同就输出
                        break;
                    }
                }
            }
        });
    }

    public void playMusicInMusicBean(Music music) {
        /*根据传入对象播放音乐*/
        stopMusic();
//                重置多媒体播放器
        mediaPlayer.reset();
//                设置新的播放路径
        TextView tx2 = findViewById(R.id.tx2);
        tx2.setText(music.getTime());
        try {
            mediaPlayer.setDataSource(music.getPath());
            playMusic();

        } catch (IOException e) {
            e.printStackTrace();
        }
        
        
        //以下是歌词显示模块

        int i =0;
        FileInputStream in = null;
        BufferedReader reader = null;
        String [] GECITIME = new String[200];   //这里设置存放二百句歌词
        String [] GECI = new String[200];
        try{
                 //利用歌曲名搜寻歌词文件
            in = openFileInput(music.getName()+".lrc");   //利用歌曲名搜寻歌词文件
            reader = new BufferedReader(new InputStreamReader(in));
            String line=null;
            while((line=reader.readLine())!=null){
                if(!line.equals("")){
                if(line.charAt(0)=='[') {
                    GECITIME[i] = line.substring(1, 6);   //  1-5个字符为时间  格式为00：00   分钟：秒钟
                    GECI[i] = line.substring(10);   //第十个字符开始是歌词
                    Log.d("歌词时间", GECITIME[i]);
                    Log.d("歌词", GECI[i]);
                    i++;
                }

                }
            }
            geci = new String[i];
            gecitime = new String[i];
            for(int j=0;j<i;j++){
                geci[j] = GECI[j];
                gecitime[j] = GECITIME[j];
            }
        }catch(FileNotFoundException e){
            geci = new String[1];
            geci[0]="0";        //如果没有歌词文件 则在数组的第一个位置放入0
            Toast.makeText(MainActivity.this,"未找到该歌词",Toast.LENGTH_SHORT).show();
        }
        catch(IOException e){
            e.printStackTrace();
        }
        finally{
            if(reader!=null)
                try{
                    reader.close();
                }catch (IOException e){
                    e.printStackTrace();
                }
        }
        

        
    }

    private void playMusic() {
        /* 播放音乐的函数*/
        if (mediaPlayer!=null&&!mediaPlayer.isPlaying()) {
            if (pause == 0) {
                try {
                    mediaPlayer.prepare();
                    mediaPlayer.start();
                    play.setImageDrawable(getResources().getDrawable(R.mipmap.zanting));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }else{
//                从暂停到播放
                mediaPlayer.seekTo(pause);
                mediaPlayer.start();
            }
        }
    }

    private void stopMusic() {
        /* 停止音乐的函数*/
        if (mediaPlayer!=null) {
            pause = 0;
            mediaPlayer.pause();
            mediaPlayer.seekTo(0);
            mediaPlayer.stop();
        }

    }




    private void jiazaimusic(){
        ContentResolver CR = getContentResolver();
        Uri uri= MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;  //获取音乐文件地址从外部地址
        //接下来需要进行遍历寻找
        Cursor cs = CR.query(uri,null,null,null,null);
        int id=0;
        while (cs.moveToNext()){
        String name = cs.getString(cs.getColumnIndex(MediaStore.Audio.Media.TITLE));
        String singer = cs.getString(cs.getColumnIndex(MediaStore.Audio.Media.ARTIST));
        String path = cs.getString(cs.getColumnIndex(MediaStore.Audio.Media.DATA));

        id++;
        String num = String.valueOf(id);
        long T = cs.getLong(cs.getColumnIndex(MediaStore.Audio.Media.DURATION));   //这个是时间  转化成long型
            SimpleDateFormat s = new SimpleDateFormat("mm:ss");  //这里是进行时间格式的转化
            String time = s.format(new Date(T));
            Music m=new Music(num,name,singer,path,time);
            mData.add(m);
        }
        Adapter.notifyDataSetChanged();

    }
    public void init(){
        SeekBar jindutiao = findViewById(R.id.jindutiao);
        SeekbarChange change = new SeekbarChange();
        jindutiao.setOnSeekBarChangeListener(change);
        qiege = (ImageButton) findViewById(R.id.qiege);
        play = (ImageButton)findViewById(R.id.play);
        shang = (ImageButton)findViewById(R.id.shang);
        xia = (ImageButton)findViewById(R.id.xia);
        tianjia = (ImageButton)findViewById(R.id.tianjia);
        shanchu = (ImageButton)findViewById(R.id.shanchu);
        music_singer = (TextView) findViewById(R.id.music_singer);
        music_name= (TextView) findViewById(R.id.music_name);
        RC = (RecyclerView) findViewById(R.id.RC);

    }
//接下来是seekbar控制进度
    private class SeekbarChange implements SeekBar.OnSeekBarChangeListener {
    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        if(fromUser)
        {
            mediaPlayer.seekTo(progress*((int)mediaPlayer.getDuration())/100);
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
        mediaPlayer.pause();
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        mediaPlayer.start();
    }
}

}